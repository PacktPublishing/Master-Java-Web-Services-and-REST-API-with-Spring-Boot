package com.in28minutes.spring.learnspringframework.game;

public interface GamingConsole {
	void up();
	void down();
	void left();
	void right();
}
